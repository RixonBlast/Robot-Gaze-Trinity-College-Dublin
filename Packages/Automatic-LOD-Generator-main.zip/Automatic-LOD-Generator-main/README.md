# Automatic-LOD-Generator
 
 ## Introduction
 Automatic level of detail generator and mesh simplifier for Unity. This project is based on the [UnityMeshSimplifier](https://github.com/Whinarn/UnityMeshSimplifier/) repository. And it aims to make the creation of the LODs process easier (2 clicks) with basic UI elements.

<img src="/Screenshot.png" width="100%">

## Notes
* [UnityMeshSimplifier](https://github.com/Whinarn/UnityMeshSimplifier/) must be added manually via the package manager. 
 
* Package Manager Window >> Add package from git URL >> https://github.com/Whinarn/UnityMeshSimplifier.git

[Icon Source](https://pixabay.com/vectors/crop-circle-glyph-sacred-geometry-5147211/)

## Video
https://youtu.be/9YOd-lwKeXU
