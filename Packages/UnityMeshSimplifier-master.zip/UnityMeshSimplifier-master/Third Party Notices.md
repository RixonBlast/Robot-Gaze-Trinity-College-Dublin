This package contains code that is largely based off of third-party software components governed by the license(s) indicated below:

Component Name: Fast-Quadric-Mesh-Simplification

License Type: "MIT"

[Fast-Quadric-Mesh-Simplification License](https://github.com/sp4cerat/Fast-Quadric-Mesh-Simplification/blob/master/src.cmd/Simplify.h)
